This directory contains the following files:

readme.txt   -- this file
kurosawa.tex -- main latex document
kurosawa.pdf  -- the paper in pdf

fig01a.eps     -- a postscript file for Figure 1
fig01b.eps     -- a postscript file for Figure 1 (second part)
fig02.eps      -- a postscript file for Figure 2
fig03.eps     -- a postscript file for Figure 3
fig04.eps     -- a postscript file for Figure 4
fig05.eps     -- a postscript file for Figure 5
